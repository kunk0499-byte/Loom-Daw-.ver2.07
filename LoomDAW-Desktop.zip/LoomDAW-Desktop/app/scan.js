'use strict';
/* scan.js — VST3 の検出。1ファイルごとに別プロセス(host --scan-one)で調べ、
 * クラッシュ/ハングするプラグインがあってもアプリ本体は巻き込まれない。結果はキャッシュ。 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

function findVst3(dir, out, depth) {
  if (depth > 6) return;
  let ents;
  try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
  for (const e of ents) {
    const p = path.join(dir, e.name);
    if (/\.vst3$/i.test(e.name)) out.push(p);          // .vst3 はファイルでもバンドル(フォルダ)でも1プラグイン扱い
    else if (e.isDirectory()) findVst3(p, out, depth + 1);
  }
}

function scanOne(hostCmd, file, timeoutMs) {
  return new Promise(resolve => {
    let out = '', done = false;
    const p = spawn(hostCmd, ['--scan-one', file], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
    const fin = r => { if (!done) { done = true; clearTimeout(t); resolve(r); } };
    const t = setTimeout(() => { try { p.kill(); } catch (e) {} fin({ failed: 'timeout' }); }, timeoutMs);
    p.stdout.on('data', d => { out += d; });
    p.on('error', e => fin({ failed: e.message }));
    p.on('exit', code => {
      if (code !== 0) return fin({ failed: 'exit ' + code });
      try { fin({ list: JSON.parse(out) }); } catch (e) { fin({ failed: 'bad output' }); }
    });
  });
}

/* cache: {[path]: {m: mtimeMs, list?:[], failed?:str}} */
async function scanAll({ hostCmd, dirs, cache, onProgress, timeoutMs = 30000 }) {
  const files = [];
  dirs.forEach(d => findVst3(d, files, 0));
  const uniq = [...new Set(files)];
  const plugins = [];
  let i = 0;
  for (const f of uniq) {
    onProgress && onProgress(++i, uniq.length, path.basename(f));
    let m = 0;
    try { m = fs.statSync(f).mtimeMs; } catch (e) {}
    let c = cache[f];
    if (!c || c.m !== m) { c = Object.assign({ m }, await scanOne(hostCmd, f, timeoutMs)); cache[f] = c; }
    (c.list || []).forEach(d => plugins.push(Object.assign({ path: f }, d)));
  }
  const failed = uniq.filter(f => cache[f] && cache[f].failed).map(f => path.basename(f) + ' (' + cache[f].failed + ')');
  return { plugins, failed, total: uniq.length };
}

module.exports = { scanAll, findVst3, scanOne };
