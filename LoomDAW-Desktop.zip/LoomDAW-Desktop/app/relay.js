'use strict';
/* relay.js — VSTホスト(stdio, 長さ前置フレーム) ⇄ レンダラ(WebSocket) の中継。
 * 依存パッケージなし（RFC6455の最小実装）。Electronに依存しないのでNodeだけでテスト可能。
 * stdioフレーム: [u32 LE 長さ][ボディ]   ボディ先頭1バイト=種別（vst-core.js 参照）
 * WebSocket   : 1メッセージ = 1ボディ（バイナリ）                                   */
const http = require('http');
const crypto = require('crypto');
const { spawn } = require('child_process');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

function wsEncode(buf, op) {
  const n = buf.length;
  let h;
  if (n < 126) { h = Buffer.alloc(2); h[1] = n; }
  else if (n < 65536) { h = Buffer.alloc(4); h[1] = 126; h.writeUInt16BE(n, 2); }
  else { h = Buffer.alloc(10); h[1] = 127; h.writeBigUInt64BE(BigInt(n), 2); }
  h[0] = 0x80 | op;
  return Buffer.concat([h, buf]);
}

class WsParser {
  constructor(onmsg) { this.b = Buffer.alloc(0); this.frag = []; this.fop = 2; this.on = onmsg; }
  push(d) {
    this.b = this.b.length ? Buffer.concat([this.b, d]) : d;
    for (;;) {
      const b = this.b;
      if (b.length < 2) return;
      const fin = !!(b[0] & 0x80), op = b[0] & 15, masked = !!(b[1] & 0x80);
      let len = b[1] & 127, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > 64 * 1024 * 1024) throw new Error('frame too large');
      let mask = null;
      if (masked) { if (b.length < off + 4) return; mask = b.subarray(off, off + 4); off += 4; }
      if (b.length < off + len) return;
      const p = Buffer.from(b.subarray(off, off + len));
      if (mask) for (let i = 0; i < p.length; i++) p[i] ^= mask[i & 3];
      this.b = b.subarray(off + len);
      if (op >= 8) { this.on(op, p); continue; }
      if (op !== 0) { this.fop = op; this.frag = []; }
      this.frag.push(p);
      if (fin) { const m = this.frag.length === 1 ? this.frag[0] : Buffer.concat(this.frag); this.frag = []; this.on(this.fop, m); }
    }
  }
}

/* opts: { hostCmd, hostArgs, token, onLog } → { port, token, close(), hostAlive() } */
function startRelay(opts) {
  const token = opts.token || crypto.randomBytes(16).toString('hex');
  const log = opts.onLog || (() => {});
  let client = null, host = null, hostBuf = Buffer.alloc(0), alive = false, closing = false;

  const toClient = body => { if (client && !client.destroyed) try { client.write(wsEncode(body, 2)); } catch (e) {} };
  const notice = obj => toClient(Buffer.concat([Buffer.from([0x81]), Buffer.from(JSON.stringify(obj))]));

  function startHost() {
    if (!opts.hostCmd) return;
    host = spawn(opts.hostCmd, opts.hostArgs || ['--serve'], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    alive = true; hostBuf = Buffer.alloc(0);
    host.stdout.on('data', d => {
      hostBuf = hostBuf.length ? Buffer.concat([hostBuf, d]) : d;
      for (;;) {
        if (hostBuf.length < 4) return;
        const n = hostBuf.readUInt32LE(0);
        if (hostBuf.length < 4 + n) return;
        toClient(Buffer.from(hostBuf.subarray(4, 4 + n)));
        hostBuf = hostBuf.subarray(4 + n);
      }
    });
    host.stderr.on('data', d => log('[host] ' + String(d).trimEnd()));
    host.stdin.on('error', () => {});
    host.on('error', e => { alive = false; log('host spawn error: ' + e.message); notice({ evt: 'hostExit', error: e.message }); });
    host.on('exit', (code, sig) => { alive = false; log('host exit ' + code + ' ' + sig); if (!closing) notice({ evt: 'hostExit', code }); });
  }
  const toHost = body => {
    if (!alive || !host) return;
    const h = Buffer.alloc(4); h.writeUInt32LE(body.length, 0);
    host.stdin.write(Buffer.concat([h, body]));
  };

  const srv = http.createServer((q, r) => { r.writeHead(404); r.end(); });
  srv.on('upgrade', (req, sock) => {
    let u; try { u = new URL(req.url, 'http://x'); } catch (e) { sock.destroy(); return; }
    const key = req.headers['sec-websocket-key'];
    if (u.searchParams.get('t') !== token || !key) { sock.write('HTTP/1.1 403 Forbidden\r\n\r\n'); sock.destroy(); return; }
    const acc = crypto.createHash('sha1').update(key + GUID).digest('base64');
    sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
    sock.setNoDelay(true);
    if (client && !client.destroyed) client.destroy();
    client = sock;
    if (!alive && !closing) startHost(); // ホストが落ちていたら再起動
    const ps = new WsParser((op, p) => {
      if (op === 1 || op === 2) toHost(p);
      else if (op === 8) { try { sock.write(wsEncode(Buffer.alloc(0), 8)); } catch (e) {} sock.end(); }
      else if (op === 9) { try { sock.write(wsEncode(p, 10)); } catch (e) {} }
    });
    sock.on('data', d => { try { ps.push(d); } catch (e) { sock.destroy(); } });
    sock.on('error', () => {});
    sock.on('close', () => { if (client === sock) client = null; });
  });

  startHost();
  return new Promise(res => srv.listen(0, '127.0.0.1', () => res({
    port: srv.address().port, token,
    hostAlive: () => alive,
    close() { closing = true; try { if (client) client.destroy(); } catch (e) {} try { srv.close(); } catch (e) {} try { if (host) host.kill(); } catch (e) {} }
  })));
}

module.exports = { startRelay, wsEncode, WsParser };
