'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('loomHost', {
  info: () => ipcRenderer.invoke('host:info'),
  scan: dirs => ipcRenderer.invoke('host:scan', dirs),
  pickFolder: () => ipcRenderer.invoke('host:pick'),
  setDirs: dirs => ipcRenderer.invoke('host:setDirs', dirs),
  saveVstState: obj => ipcRenderer.invoke('host:saveState', obj),
  loadVstState: () => ipcRenderer.invoke('host:loadState'),
  onScanProgress: f => { ipcRenderer.on('host:scanProgress', (_e, a) => f(a)); }
});
