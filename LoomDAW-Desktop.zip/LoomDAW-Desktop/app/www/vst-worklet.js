/* vst-worklet.js — AudioWorklet: Web Audio ⇄ 共有リングバッファ。ヘッダ番号は vst-core.js の H と一致させること */
'use strict';
const H_IN_W = 0, H_IN_R = 1, H_OUT_W = 2, H_OUT_R = 3, H_SKIP = 4, H_ACTIVE = 5, H_STARTED = 6, H_UNDER = 7, H_OVER = 8, H_S0LO = 9, H_S0HI = 10, H_DELAY = 11, H_BLOCK = 12, H_GAP = 13;

class LoomVstIO extends AudioWorkletProcessor {
  constructor(o) {
    super();
    const p = o.processorOptions;
    this.h = new Int32Array(p.sab, 0, 16);
    this.cap = p.cap; this.mask = p.cap - 1;
    this.inR = new Float32Array(p.sab, 64, p.cap * 2);
    this.outR = new Float32Array(p.sab, 64 + p.cap * 8, p.cap * 2);
    this.alive = true;
    this.port.onmessage = e => { if (e.data === 'kill') this.alive = false; };
  }
  process(inputs, outputs) {
    if (!this.alive) return false;
    const h = this.h, out = outputs[0];
    if (!out || !out[0]) return true;
    if (!Atomics.load(h, H_ACTIVE)) return true;           // 無効中は無音
    const n = out[0].length, mask = this.mask;
    if (Atomics.load(h, H_STARTED) === 0) {                // 有効化直後: 絶対フレームを記録し、OUTへ遅延分の無音を先詰め
      const f = currentFrame;
      Atomics.store(h, H_S0LO, f | 0);
      Atomics.store(h, H_S0HI, Math.floor(f / 4294967296) | 0);
      Atomics.store(h, H_OUT_W, Atomics.load(h, H_DELAY));
      Atomics.store(h, H_OUT_R, 0);
      Atomics.store(h, H_STARTED, 1);
    }
    /* 入力 → IN リング */
    const inp = inputs[0], L = inp && inp[0], R = (inp && inp[1]) || L;
    const w = Atomics.load(h, H_IN_W), r = Atomics.load(h, H_IN_R);
    if (this.cap - ((w - r) | 0) >= n) {
      const d = this.inR;
      for (let i = 0; i < n; i++) { const o = ((w + i) & mask) * 2; d[o] = L ? L[i] : 0; d[o + 1] = R ? R[i] : 0; }
      const nw = (w + n) | 0;
      Atomics.store(h, H_IN_W, nw);
      if (((nw - r) | 0) >= Atomics.load(h, H_BLOCK)) Atomics.notify(h, H_IN_W);
    } else { Atomics.add(h, H_OVER, 1); Atomics.add(h, H_GAP, n); }
    /* OUT リング → 出力 */
    let rr = Atomics.load(h, H_OUT_R), skip = Atomics.load(h, H_SKIP);
    const ww = Atomics.load(h, H_OUT_W);
    let avail = (ww - rr) | 0;
    if (skip > 0) { const d = Math.min(avail, skip); rr = (rr + d) | 0; avail -= d; skip -= d; }
    const cnt = Math.min(avail, n), o0 = out[0], o1 = out[1] || out[0], s = this.outR;
    for (let i = 0; i < cnt; i++) { const o = ((rr + i) & mask) * 2; o0[i] = s[o]; if (o1 !== o0) o1[i] = s[o + 1]; }
    if (cnt < n) {                                         // アンダーラン: 無音を出し、遅れて届く分は捨てて遅延を一定に保つ
      for (let i = cnt; i < n; i++) { o0[i] = 0; if (o1 !== o0) o1[i] = 0; }
      skip += n - cnt; Atomics.add(h, H_UNDER, 1);
    }
    Atomics.store(h, H_OUT_R, (rr + cnt) | 0);
    Atomics.store(h, H_SKIP, skip);
    return true;
  }
}
registerProcessor('loom-vst-io', LoomVstIO);
