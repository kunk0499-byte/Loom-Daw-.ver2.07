/* vst-worker.js — ホストへのWebSocketを持ち、各インスタンスのリングを回す専用Worker */
'use strict';
importScripts('vst-core.js');
const C = LoomVstCore, H = C.H;
let ws = null;
const inst = new Map();   // id -> {v, inst, B, s0, total, alive}

const post = (m, tr) => self.postMessage(m, tr || []);
const send = buf => { if (ws && ws.readyState === 1) ws.send(buf); };

async function pump(s) {
  const h = s.v.h;
  while (s.alive) {
    if (Atomics.load(h, H.ACTIVE)) C.drain(s, b => send(b));   // 未接続でも読み捨てて遅延が溜まらないようにする
    const w = Atomics.load(h, H.IN_W);
    try {
      const r = Atomics.waitAsync(h, H.IN_W, w, 20);
      if (r.async) await r.value;
    } catch (e) { await new Promise(r => setTimeout(r, 5)); }
  }
}

function connect(url) {
  if (ws) try { ws.close(); } catch (e) {}
  ws = new WebSocket(url);
  ws.binaryType = 'arraybuffer';
  ws.onopen = () => post({ t: 'open' });
  ws.onclose = () => post({ t: 'close' });
  ws.onerror = () => post({ t: 'error' });
  ws.onmessage = e => {
    const b = e.data, ty = new Uint8Array(b)[0];
    if (ty === C.T.AUDIO_OUT) { const s = inst.get(C.audioInst(b)); if (s) C.onAudioOut(s, b); }
    else if (ty === C.T.JSON_H) post({ t: 'json', msg: C.decodeJson(b) });
  };
}

self.onmessage = e => {
  const m = e.data;
  if (m.t === 'connect') connect(m.url);
  else if (m.t === 'attach') {
    const v = C.views(m.sab, m.cap), s = { v, inst: m.inst, B: m.B, s0: null, total: 0, alive: true };
    inst.set(m.inst, s); pump(s);
  } else if (m.t === 'detach') {
    const s = inst.get(m.inst); if (s) { s.alive = false; inst.delete(m.inst); Atomics.notify(s.v.h, H.IN_W); }
  } else if (m.t === 'send') send(m.buf);
};
