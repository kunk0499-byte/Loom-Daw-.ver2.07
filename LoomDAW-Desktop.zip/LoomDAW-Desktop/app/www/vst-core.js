/* vst-core.js — リングバッファ / フレーム形式（Worker・ブリッジ・テストで共用）
 *
 * SharedArrayBuffer（インスタンスごと）
 *   [0..63]  ヘッダ Int32 x16
 *   [64..]   IN リング  (AudioWorklet → Worker) cap フレーム × 2ch float32 interleaved
 *   [..]     OUT リング (Worker → AudioWorklet) 同上
 *
 * ソケット上のボディ（リトルエンディアン）
 *   0x01 JSON要求 : [type][UTF-8 JSON]            0x81 JSON応答/通知
 *   0x02 AUDIO_IN : [type][pad3][inst u32][startFrame f64][n u32][f32 × n × 2]   (ヘッダ20B)
 *   0x82 AUDIO_OUT: 同形式
 *   0x03 EVENTS   : [type][pad3][inst u32][count u32] + count × {frame f64,status u8,d1 u8,d2 u8,kind u8,handle u32}
 *        kind 0=MIDIイベント / 1=handle一致の未発音イベントを取消 / 2=キュー全消去+全ノートオフ
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.LoomVstCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const H = { IN_W: 0, IN_R: 1, OUT_W: 2, OUT_R: 3, SKIP: 4, ACTIVE: 5, STARTED: 6, UNDER: 7, OVER: 8, S0LO: 9, S0HI: 10, DELAY: 11, BLOCK: 12, GAP: 13 };
  const HDR = 64;
  const T = { JSON_C: 1, AUDIO_IN: 2, EVENTS: 3, JSON_H: 0x81, AUDIO_OUT: 0x82 };
  const AUDIO_HDR = 20, EV_HDR = 12, EV_REC = 16;
  const pow2 = n => { let p = 1; while (p < n) p <<= 1; return p; };
  const makeSab = cap => new SharedArrayBuffer(HDR + cap * 16);
  const views = (sab, cap) => ({
    h: new Int32Array(sab, 0, 16),
    inR: new Float32Array(sab, HDR, cap * 2),
    outR: new Float32Array(sab, HDR + cap * 8, cap * 2),
    cap, mask: cap - 1
  });
  const start0 = h => (Atomics.load(h, H.S0HI) >>> 0) * 4294967296 + (Atomics.load(h, H.S0LO) >>> 0);

  function resetRings(h, delay, block) {
    [H.IN_W, H.IN_R, H.OUT_W, H.OUT_R, H.SKIP, H.STARTED, H.UNDER, H.OVER, H.S0LO, H.S0HI, H.GAP, H.ACTIVE].forEach(i => Atomics.store(h, i, 0));
    Atomics.store(h, H.DELAY, delay | 0);
    Atomics.store(h, H.BLOCK, block | 0);
  }

  /* Worker: IN から B フレームずつ取り出してパケット化。s={v,inst,B,s0,total} */
  function drain(s, send) {
    const v = s.v, h = v.h;
    if (Atomics.load(h, H.STARTED) === 0) return 0;
    if (s.s0 == null) { s.s0 = start0(h); s.total = s.total || 0; }
    let sent = 0;
    for (;;) {
      const w = Atomics.load(h, H.IN_W), r = Atomics.load(h, H.IN_R);
      if (((w - r) | 0) < s.B) break;
      const gap = Atomics.exchange(h, H.GAP, 0);
      if (gap) s.total += gap;
      const pk = encodeAudio(T.AUDIO_IN, s.inst, s.s0 + s.total, s.B);
      const d = pk.data, mask = v.mask, src = v.inR;
      for (let i = 0; i < s.B; i++) {
        const o = ((r + i) & mask) * 2;
        d[i * 2] = src[o]; d[i * 2 + 1] = src[o + 1];
      }
      Atomics.store(h, H.IN_R, (r + s.B) | 0);
      s.total += s.B;
      send(pk.buf);
      sent++;
    }
    return sent;
  }

  /* Worker: ホストから戻ったブロックを OUT リングへ */
  function onAudioOut(s, buf) {
    const dv = new DataView(buf);
    const n = dv.getUint32(16, true);
    const data = new Float32Array(buf, AUDIO_HDR, n * 2);
    const v = s.v, h = v.h, mask = v.mask, dst = v.outR;
    const w = Atomics.load(h, H.OUT_W), r = Atomics.load(h, H.OUT_R);
    if (v.cap - ((w - r) | 0) < n) { Atomics.add(h, H.OVER, 1); return false; }
    for (let i = 0; i < n; i++) {
      const o = ((w + i) & mask) * 2;
      dst[o] = data[i * 2]; dst[o + 1] = data[i * 2 + 1];
    }
    Atomics.store(h, H.OUT_W, (w + n) | 0);
    return true;
  }

  function encodeAudio(type, inst, start, n) {
    const buf = new ArrayBuffer(AUDIO_HDR + n * 8), dv = new DataView(buf);
    dv.setUint8(0, type); dv.setUint32(4, inst >>> 0, true);
    dv.setFloat64(8, start, true); dv.setUint32(16, n, true);
    return { buf, data: new Float32Array(buf, AUDIO_HDR, n * 2) };
  }
  const audioInst = buf => new DataView(buf).getUint32(4, true);

  function encodeEvents(inst, evs) {
    const buf = new ArrayBuffer(EV_HDR + evs.length * EV_REC), dv = new DataView(buf);
    dv.setUint8(0, T.EVENTS); dv.setUint32(4, inst >>> 0, true); dv.setUint32(8, evs.length, true);
    evs.forEach((e, i) => {
      const o = EV_HDR + i * EV_REC;
      dv.setFloat64(o, e[0], true); dv.setUint8(o + 8, e[1] | 0); dv.setUint8(o + 9, e[2] | 0);
      dv.setUint8(o + 10, e[3] | 0); dv.setUint8(o + 11, e[4] | 0); dv.setUint32(o + 12, (e[5] || 0) >>> 0, true);
    });
    return buf;
  }
  function decodeEvents(buf) {
    const dv = new DataView(buf), n = dv.getUint32(8, true), out = [];
    for (let i = 0; i < n; i++) {
      const o = EV_HDR + i * EV_REC;
      out.push([dv.getFloat64(o, true), dv.getUint8(o + 8), dv.getUint8(o + 9), dv.getUint8(o + 10), dv.getUint8(o + 11), dv.getUint32(o + 12, true)]);
    }
    return { inst: dv.getUint32(4, true), events: out };
  }

  const enc = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null;
  const dec = typeof TextDecoder !== 'undefined' ? new TextDecoder() : null;
  function encodeJson(type, obj) {
    const body = enc.encode(JSON.stringify(obj)), u = new Uint8Array(1 + body.length);
    u[0] = type; u.set(body, 1); return u.buffer;
  }
  const decodeJson = buf => JSON.parse(dec.decode(new Uint8Array(buf, 1)));

  return { H, HDR, T, AUDIO_HDR, EV_HDR, EV_REC, pow2, makeSab, views, start0, resetRings, drain, onAudioOut, encodeAudio, audioInst, encodeEvents, decodeEvents, encodeJson, decodeJson };
});
