/* vst-bridge.js — Loom DAW 本体(classic script)の後に読み込まれ、VST3 を LoomFX / LoomInst として登録する。
 * 本体の top-level const/let（S, ac, tab, LoomFX, LoomInst, FXT, INS …）はグローバル字句スコープ経由で参照できる。 */
(function () {
  'use strict';
  if (!window.loomHost || typeof LoomFX === 'undefined' || typeof LoomVstCore === 'undefined') return;
  const C = LoomVstCore, H = C.H;
  const DELAY = 2048, BLOCK = 256, CAP = 16384;      // 遅延 ≈ 43ms@48kHz。音切れが出る場合は DELAY を増やす
  let worker = null, wsUp = false, info = null, nextInst = 1, nextReq = 1, gotOpen = null, retryT = 0;
  const pend = new Map(), insts = new Map(), wmod = new WeakMap();
  const openP = new Promise(r => { gotOpen = r; });
  const isOff = c => typeof OfflineAudioContext !== 'undefined' && c instanceof OfflineAudioContext;

  /* ───── ホストとの JSON 要求/応答 ───── */
  function req(cmd, obj, ms) {
    return new Promise(res => {
      const id = nextReq++;
      const t = setTimeout(() => { pend.delete(id); res({ ok: false, error: 'timeout' }); }, ms || 20000);
      pend.set(id, r => { clearTimeout(t); res(r); });
      const b = C.encodeJson(C.T.JSON_C, Object.assign({ id, cmd }, obj || {}));
      worker.postMessage({ t: 'send', buf: b }, [b]);
    });
  }
  function onWorker(e) {
    const m = e.data;
    if (m.t === 'open') {
      wsUp = true; gotOpen();
      insts.forEach(o => { if (o.booted) reattach(o); });      // 再接続: 全インスタンスを作り直す
    } else if (m.t === 'close' || m.t === 'error') {
      if (wsUp) toast('VSTホストとの接続が切れました。再接続します…');
      wsUp = false; insts.forEach(o => { Atomics.store(o.v.h, H.ACTIVE, 0); });
      clearTimeout(retryT); retryT = setTimeout(connect, 1500);
    } else if (m.t === 'json') {
      const j = m.msg;
      if (j.id && pend.has(j.id)) { const f = pend.get(j.id); pend.delete(j.id); f(j); }
      else if (j.evt === 'state') onState(j.inst, j.state);
      else if (j.evt === 'hostExit') toast('VSTホストが終了しました（次の接続時に再起動します）');
    }
  }
  function connect() { worker.postMessage({ t: 'connect', url: 'ws://127.0.0.1:' + info.port + '/?t=' + info.token }); }

  /* ───── 状態（プラグインのプリセット/設定）の保存 ───── */
  let vstT = 0;
  function onState(id, state) {
    const o = insts.get(id); if (!o || !state) return;
    (S.vst = S.vst || {})[o.key] = state;
    try { dirty = true; } catch (e) {}
    clearTimeout(vstT); vstT = setTimeout(() => { try { loomHost.saveVstState(S.vst); } catch (e) {} }, 800);
  }

  /* ───── インスタンス ───── */
  const ensure = ctx => { let p = wmod.get(ctx); if (!p) { p = ctx.audioWorklet.addModule('vst-worklet.js'); wmod.set(ctx, p); } return p; };
  async function createOnHost(o) {
    return req('create', { inst: o.id, path: o.pl.path, uid: o.pl.uid, name: o.pl.name, sr: o.ctx.sampleRate, block: BLOCK, instrument: o.isInst, state: (S.vst && S.vst[o.key]) || null }, 30000);
  }
  async function boot(o) {
    try {
      await openP;
      await ensure(o.ctx);
      if (!o.alive) return;
      C.resetRings(o.v.h, DELAY, BLOCK);
      const n = new AudioWorkletNode(o.ctx, 'loom-vst-io', { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2], processorOptions: { sab: o.sab, cap: CAP } });
      o.node = n;
      worker.postMessage({ t: 'attach', inst: o.id, sab: o.sab, cap: CAP, B: BLOCK });
      const r = await createOnHost(o);
      if (!o.alive) return;
      if (!r.ok) { o.status = '読み込み失敗: ' + (r.error || '?'); toast('VST「' + o.pl.name + '」を読み込めませんでした: ' + (r.error || '')); return; }
      o.status = 'OK' + (r.latency ? '（プラグイン遅延 ' + r.latency + ' サンプル）' : '');
      o.hasEditor = r.hasEditor !== false;
      if (!o.isInst) { try { o.input.disconnect(o.output); } catch (e) {} o.input.connect(n); }
      n.connect(o.output);
      o.booted = true;
      Atomics.store(o.v.h, H.ACTIVE, 1);
    } catch (e) { console.error(e); o.status = 'エラー: ' + (e && e.message || e); }
  }
  async function reattach(o) {
    Atomics.store(o.v.h, H.ACTIVE, 0);
    C.resetRings(o.v.h, DELAY, BLOCK);
    const r = await createOnHost(o);
    if (r.ok && o.alive) Atomics.store(o.v.h, H.ACTIVE, 1);
  }
  function flush(o) {
    o.flushT = 0; if (!o.evq.length) return;
    const b = C.encodeEvents(o.id, o.evq); o.evq = [];
    worker.postMessage({ t: 'send', buf: b }, [b]);
  }
  const evPush = (o, e) => { o.evq.push(e); if (!o.flushT) o.flushT = setTimeout(() => flush(o), 0); };

  function makeInstance(ctx, pl, key, isInst) {
    const input = ctx.createGain(), output = ctx.createGain();
    if (isOff(ctx)) {                                    // オフライン・レンダリング: 現状 VST は含まれない
      if (!isInst) input.connect(output);
      let warned = false;
      return { input, output, noteOn() { if (!warned) { warned = true; toast('VST音源はオフライン書き出し/波形化に含まれません（リアルタイム再生のみ対応）'); } return { stop() {} }; }, allOff() {}, update() {}, dispose() {} };
    }
    const sab = C.makeSab(CAP);
    const o = { id: nextInst++, pl, key, isInst, ctx, input, output, node: null, sab, v: C.views(sab, CAP), alive: true, booted: false, evq: [], flushT: 0, hid: 1, status: '接続中…', hasEditor: true };
    insts.set(o.id, o);
    if (!isInst) input.connect(output);                  // 準備が整うまでバイパス
    boot(o);
    const sr = () => ctx.sampleRate;
    return {
      input, output,
      get status() { return o.status; },
      noteOn(note, vel, when, dur) {
        const h = o.hid++, v = Math.max(1, Math.min(127, Math.round((vel == null ? .8 : vel) * 127)));
        evPush(o, [when * sr() - DELAY, 0x90, note, v, 0, h]);
        evPush(o, [(when + dur) * sr() - DELAY, 0x80, note, 0, 0, h]);
        return { stop(started) {
          evPush(o, [0, 0, 0, 0, 1, h]);                  // 未発音ならイベント取消
          if (started) evPush(o, [ctx.currentTime * sr() - DELAY, 0x80, note, 0, 0, 0]);
        } };
      },
      allOff() { evPush(o, [0, 0, 0, 0, 2, 0]); },
      update() {},
      openEditor() { return req('editor', { inst: o.id, open: true }); },
      dispose() {
        if (!o.alive) return; o.alive = false;
        try { Atomics.store(o.v.h, H.ACTIVE, 0); } catch (e) {}
        try { if (o.node) { o.node.port.postMessage('kill'); o.node.disconnect(); } } catch (e) {}
        try { input.disconnect(); } catch (e) {} try { output.disconnect(); } catch (e) {}
        worker.postMessage({ t: 'detach', inst: o.id });
        insts.delete(o.id);
        if (wsUp) req('destroy', { inst: o.id }, 5000);
      }
    };
  }

  /* ───── プラグイン UI（エディタを開くボタン） ───── */
  function mkUI(kind) {
    return function (box, api) {
      box.style.cssText += ';display:flex;flex-direction:column;align-items:stretch;justify-content:center;gap:6px;padding:8px 12px;font:11.5px system-ui,sans-serif;color:#92959b';
      const b = document.createElement('button'), s = document.createElement('div');
      b.textContent = 'プラグイン画面を開く';
      b.style.cssText = 'height:28px;border:0;border-radius:2px;background:#47494e;color:#e3e4e6;cursor:pointer;font:inherit';
      s.style.cssText = 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis';
      box.append(b, s);
      b.onclick = () => { const u = api.node(); if (u && u.openEditor) u.openEditor(); else toast('VSTを準備中です'); };
      const tm = setInterval(() => { const u = api.node(); s.textContent = kind + ' · ' + (u && u.status || '未接続'); }, 600);
      return { destroy() { clearInterval(tm); } };
    };
  }

  const hash = s => { let a = 5381, b = 52711; for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); a = (a * 33) ^ c; b = (b * 33) ^ c; } return ((a >>> 0).toString(36) + (b >>> 0).toString(36)).slice(0, 16); };
  function registerPlugins(list) {
    (list || []).forEach(pl => {
      const id = 'vst_' + hash(pl.path + '|' + pl.uid + '|' + pl.name);
      const key = (pl.isInstrument ? 'i:' : 'x:') + id;
      const common = { id, name: pl.name, color: pl.isInstrument ? '#ff9a3c' : '#7a9cff', width: pl.isInstrument ? 280 : 240, desc: 'VST3 · ' + (pl.vendor || ''), label: 'VST3', params: [], ui: mkUI('VST3'), uiHeight: 70, hideKnobs: true };
      try {
        if (pl.isInstrument) LoomInst.register(Object.assign(common, { gain: 1, tail: 3, create: (ctx, hh) => makeInstance(ctx, pl, (hh && hh.key) || key, true) }));
        else LoomFX.register(Object.assign(common, { create: (ctx, hh) => makeInstance(ctx, pl, (hh && hh.key) || key, false) }));
      } catch (e) { console.warn('register failed', pl.name, e); }
    });
  }
  function refreshDaw() {
    try {
      if (ac && !playing) { try { RTM.m.forEach(r => { try { r.o.disconnect(); } catch (e) {} }); RTM.m.clear(); RTM.sig = null; } catch (e) {} resetG(); fx(); }
      plResolve(); libUI(); tracksUI(); if (tab === 'fx') fxUI(); try { ipwKey = ''; ipwSync(); } catch (e) {}
    } catch (e) { console.warn(e); }
  }

  /* ───── VST パネル（ヘッダの「VST」ボタン） ───── */
  let panel = null, dirs = [];
  function panelUI() {
    if (panel) { panel.remove(); panel = null; return; }
    panel = document.createElement('div');
    panel.style.cssText = 'position:fixed;right:24px;top:70px;z-index:60;width:420px;max-height:70vh;overflow:auto;background:var(--pn);border:1px solid var(--ln);border-radius:4px;box-shadow:0 14px 34px var(--sh);padding:10px 12px;display:grid;gap:8px;user-select:text';
    const render = (msg) => {
      panel.innerHTML = '<b>VSTプラグイン（VST3）</b><div class="em">検索フォルダ:</div>' +
        dirs.map((d, i) => `<div style="display:flex;gap:6px"><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(d)}">${esc(d)}</span><button data-rm="${i}">×</button></div>`).join('') +
        '<div style="display:flex;gap:6px"><button data-a="add">フォルダを追加</button><button data-a="scan" class="a">スキャン</button><button data-a="close">閉じる</button></div>' +
        `<div class="em" id="vstmsg">${msg || ''}</div>`;
    };
    const cur_ = () => (info.plugins && info.plugins.plugins || []);
    render((cur_().length) + ' 個のプラグインを登録済み' + (info.ok ? '' : '（VSTホストが見つかりません）'));
    loomHost.onScanProgress(p => { const m = panel && panel.querySelector('#vstmsg'); if (m) m.textContent = 'スキャン中 ' + p.i + '/' + p.n + ' ' + p.nm; });
    panel.onclick = async e => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.rm != null) { dirs.splice(+b.dataset.rm, 1); loomHost.setDirs(dirs); render(); }
      else if (b.dataset.a === 'add') { const d = await loomHost.pickFolder(); if (d && !dirs.includes(d)) { dirs.push(d); loomHost.setDirs(dirs); } render(); }
      else if (b.dataset.a === 'close') panelUI();
      else if (b.dataset.a === 'scan') {
        render('スキャン中…（初回は数分かかることがあります）');
        const r = await loomHost.scan(dirs);
        info.plugins = r; registerPlugins(r.plugins); refreshDaw();
        render(r.plugins.length + ' 個のプラグインを登録しました' + (r.failed && r.failed.length ? '（読み込めなかった: ' + r.failed.length + ' 件 — ' + esc(r.failed.slice(0, 5).join(', ')) + '）' : ''));
      }
    };
    document.body.appendChild(panel);
  }
  const btn = document.getElementById('vstb');
  if (btn) btn.onclick = panelUI;

  /* ───── 起動 ───── */
  (async function init() {
    info = await loomHost.info();
    dirs = info.dirs || [];
    try { const st = await loomHost.loadVstState(); S.vst = Object.assign({}, st || {}, S.vst || {}); } catch (e) {}
    if (!info.ok) { if (btn) btn.title = 'VSTホストが見つかりません（インストールが不完全です）'; return; }
    if (!crossOriginIsolated) { toast('SharedArrayBufferが使えないためVSTを無効化しました'); return; }
    worker = new Worker('vst-worker.js');
    worker.onmessage = onWorker;
    connect();
    registerPlugins(info.plugins && info.plugins.plugins);
    if (info.plugins && info.plugins.plugins && info.plugins.plugins.length) refreshDaw();
    else if (btn) { /* 初回: ユーザーが「VST」→スキャンを押す */ }
  })();
  /* VST音源トラックは最初の音を待たずに先行してインスタンス化する（初回の音が欠けない / 遅れないように） */
  setInterval(() => {
    try {
      if (!ac || OFFL || !wsUp) return;
      S.tracks.forEach(t => { if (t.cat === 7 && t.plug && /^i:vst_/.test(t.plug.id) && INS[t.plug.id] && !IM.has(t)) instFor(t); });
    } catch (e) {}
  }, 700);
  window.__loomVst = { insts, req, registerPlugins };
})();
