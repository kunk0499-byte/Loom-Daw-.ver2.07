'use strict';
const { app, BrowserWindow, protocol, net, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { startRelay } = require('./relay');
const { scanAll } = require('./scan');

protocol.registerSchemesAsPrivileged([{ scheme: 'app', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } }]);

const WWW = path.join(__dirname, 'www');
const UD = () => app.getPath('userData');
const jread = (f, d) => { try { return JSON.parse(fs.readFileSync(path.join(UD(), f), 'utf8')); } catch (e) { return d; } };
const jwrite = (f, o) => { try { fs.writeFileSync(path.join(UD(), f), JSON.stringify(o)); } catch (e) { console.error(e); } };

function hostPath() {
  if (process.env.LOOM_HOST) return process.env.LOOM_HOST;
  const c = [path.join(process.resourcesPath || '', 'host', 'LoomVstHost.exe'), path.join(__dirname, '..', 'build', 'host', 'LoomVstHost.exe')];
  return c.find(p => fs.existsSync(p)) || null;
}

let relay = null, win = null;
const DEFAULT_DIRS = () => [
  path.join(process.env.CommonProgramFiles || 'C:\\Program Files\\Common Files', 'VST3'),
  path.join(process.env.LOCALAPPDATA || '', 'Programs', 'Common', 'VST3')
];

app.whenReady().then(async () => {
  protocol.handle('app', async req => {
    const u = new URL(req.url);
    let rel = decodeURIComponent(u.pathname);
    if (rel === '/' || rel === '') rel = '/index.html';
    const f = path.normalize(path.join(WWW, rel));
    if (!f.startsWith(WWW)) return new Response('forbidden', { status: 403 });
    const r = await net.fetch(pathToFileURL(f).toString());
    const h = new Headers(r.headers);
    h.set('Cross-Origin-Opener-Policy', 'same-origin');          // SharedArrayBuffer に必須
    h.set('Cross-Origin-Embedder-Policy', 'credentialless');     // Google Fonts 等の外部読み込みを許可
    h.set('Cross-Origin-Resource-Policy', 'same-origin');
    if (/\.js$/i.test(f)) h.set('Content-Type', 'text/javascript');
    return new Response(r.body, { status: r.status, headers: h });
  });

  const hp = hostPath();
  const cmd = hp || undefined;
  relay = await startRelay({ hostCmd: cmd, hostArgs: ['--serve'], onLog: s => console.log(s) });

  ipcMain.handle('host:info', () => ({
    ok: !!hp, hostPath: hp, port: relay.port, token: relay.token,
    dirs: jread('vst-dirs.json', DEFAULT_DIRS()), plugins: jread('vst-plugins.json', { plugins: [], failed: [] })
  }));
  ipcMain.handle('host:setDirs', (_e, d) => { jwrite('vst-dirs.json', d); return true; });
  ipcMain.handle('host:pick', async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openDirectory'] });
    return r.canceled ? null : r.filePaths[0];
  });
  ipcMain.handle('host:scan', async (e, dirs) => {
    if (!hp) return { plugins: [], failed: [], total: 0, error: 'host not found' };
    jwrite('vst-dirs.json', dirs);
    const cache = jread('vst-scancache.json', {});
    const r = await scanAll({ hostCmd: hp, dirs, cache, onProgress: (i, n, nm) => e.sender.send('host:scanProgress', { i, n, nm }) });
    jwrite('vst-scancache.json', cache); jwrite('vst-plugins.json', r);
    return r;
  });
  ipcMain.handle('host:saveState', (_e, o) => { jwrite('vst-state.json', o); return true; });
  ipcMain.handle('host:loadState', () => jread('vst-state.json', {}));

  win = new BrowserWindow({
    width: 1500, height: 900, backgroundColor: '#222426', icon: path.join(__dirname, '..', 'build', 'icon.ico'), title: 'Loom DAW', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false }
  });
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('app://')) e.preventDefault(); });
  win.loadURL('app://loom/index.html');
});

app.on('window-all-closed', () => { if (relay) relay.close(); app.quit(); });
app.on('before-quit', () => { if (relay) relay.close(); });
