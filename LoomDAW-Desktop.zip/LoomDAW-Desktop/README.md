# Loom DAW Desktop（Windows）+ VST3 対応

Loom DAW（HTML）を Electron でデスクトップアプリ化し、JUCE 製の VST3 ホスト（サイドカー）経由で VST3 を鳴らします。

## install.exe の作り方（Windows または GitHub Actions）

1. **GitHub Actions を使う場合（推奨・手元に環境不要）**
   このフォルダを GitHub リポジトリに push → Actions の `build-windows-installer` を実行 → Artifacts の `install-exe` が `install.exe`。
2. **手元の Windows で作る場合**（Node 22、Visual Studio 2022 Build Tools(C++)、CMake が必要）
   ```
   cmake -S host -B host/_b -A x64 -DCMAKE_BUILD_TYPE=Release
   cmake --build host/_b --config Release --parallel
   mkdir build\host & copy host\_b\LoomVstHost_artefacts\Release\LoomVstHost.exe build\host\
   npm install
   npm run dist          :: dist\install.exe ができる
   ```
`npm start` で開発起動（先に `build\host\LoomVstHost.exe` が必要）。

## 構成
```
source/Loom_DAW__Ver2_07.html   元のDAW（無改変）
scripts/make-www.js             DAWに最小パッチ(9箇所)を当てて app/www/index.html を生成。一致しないと失敗するので、DAW更新時に気づける
app/main.js, preload.js         Electron本体（app:// で配信し COOP/COEP を付与＝SharedArrayBuffer用）
app/relay.js                    ホスト(stdio) ⇄ WebSocket(127.0.0.1, トークン付き) 中継（依存なし）
app/scan.js                     VST3スキャン（1ファイルごとに別プロセス・タイムアウト・キャッシュ）
app/www/vst-*.js                core(リング/フレーム形式) / worklet / worker / bridge(LoomFX・LoomInst登録とUI)
host/                           JUCE VST3ホスト（C++）
test/                           run-tests.js（Node）/ browser-smoke.js（Chromium通しテスト）/ mock-host.js
```

## 使い方
- ヘッダの **「VST」** → フォルダを確認(既定は `C:\Program Files\Common Files\VST3`) → **スキャン**。
- VST音源はブラウザの「音源プラグイン」から、トラックへクリックまたはドラッグ。インスペクタの「音源画面を開く」→「プラグイン画面を開く」でGUIが開く。
- VSTエフェクトはエフェクトタブの「＋ ノード追加」から（トラック／マスター両方）。
- プラグインの設定は自動で保存（`%APPDATA%/Loom DAW/vst-state.json`）、`.loom` プロジェクトにも含まれます。

## 仕組みと遅延
Web Audio → AudioWorklet → 共有メモリのリング → Worker → WebSocket → relay → ホスト(stdio) → `processBlock` → 逆経路。
MIDIは絶対フレーム位置つきで送り、ホストがブロック内でサンプル精度に配置。出力は固定遅延(`DELAY`=2048サンプル≈43ms)で一定に保ちます（`vst-bridge.js` 冒頭で調整。音切れが出る場合は増やす）。

## 既知の制限（正直に）
- **VST3のみ**。VST2はライセンス上/技術上対象外。
- **オフライン書き出し（ミックスダウン・波形化）にVSTは含まれません**（VST音源は無音、VSTエフェクトは素通り）。リアルタイム再生のみ対応。実装した場合はブロック単位の同期ステップが必要です。
- プラグインのパラメータはDAWのノブ/オートメーションには出ません（プラグインGUIで操作）。
- プラグイン遅延補償(PDC)は未実装（報告値のみ表示）。
- C++ホストは **このサンドボックスではコンパイルできていません**（JUCE取得・MSVC不可）。初回のCIビルドでコンパイルエラーが出る可能性があります。
