'use strict';
/* make-www.js — source/Loom_DAW__*.html に最小限のパッチを当てて app/www/index.html を生成する。
 * 各パッチは「ちょうど1回一致」しなければ失敗する（DAW本体が更新されて合わなくなったことに気づける）。 */
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const srcDir = path.join(root, 'source');
const srcFile = process.argv[2] || fs.readdirSync(srcDir).filter(f => /\.html$/i.test(f)).sort().pop();
let h = fs.readFileSync(path.join(srcDir, srcFile), 'utf8');

function patch(name, from, to, count = 1) {
  const n = h.split(from).length - 1;
  if (n !== count) throw new Error(`patch "${name}": ${n} matches (expected ${count})`);
  h = h.split(from).join(to);
}

/* 1. プラグインへ「トラックID / ノード位置」キーを渡す（VST状態の保存先に使う） */
patch('inst-create-key',
  "try{u=d.create(c,{ramp:(p,v,imm,tc)=>ramp(p,v,c,imm,tc),bpm:()=>S.bpm,stepSec:()=>sd(),LITE})}catch(e){console.error(e);toast('音源プラグイン「'",
  "try{u=d.create(c,{key:'i:'+tr.id,ramp:(p,v,imm,tc)=>ramp(p,v,c,imm,tc),bpm:()=>S.bpm,stepSec:()=>sd(),LITE})}catch(e){console.error(e);toast('音源プラグイン「'");
patch('fx-make-sig',
  "make(c){const i=c.createGain(),o=c.createGain(),dy=c.createGain(),wt=c.createGain();dy.gain.value=0;let u;",
  "make(c,nk){const i=c.createGain(),o=c.createGain(),dy=c.createGain(),wt=c.createGain();dy.gain.value=0;let u;");
patch('fx-create-key',
  "try{u=d.create(c,{ramp:(p,v,imm,tc)=>ramp(p,v,c,imm,tc),bpm:()=>S.bpm,stepSec:()=>sd(),LITE})}catch(e){console.error(e);toast('プラグイン「'",
  "try{u=d.create(c,{key:'x:'+nk,ramp:(p,v,imm,tc)=>ramp(p,v,c,imm,tc),bpm:()=>S.bpm,stepSec:()=>sd(),LITE})}catch(e){console.error(e);toast('プラグイン「'");
patch('fgSync-make',
  "const r=FXT[x.ty].make(R.c);r.ty=x.ty;",
  "const r=FXT[x.ty].make(R.c,(R.og()===S?'m':(R.og().id||'t'))+':'+x.id);r.ty=x.ty;");

/* 2. ノード削除・全リセット時に外部プラグインを dispose する（ホスト側インスタンスの解放） */
patch('fgSync-dispose',
  "{try{r.o.disconnect()}catch(e){}R.m.delete(id)}});",
  "{try{r.o.disconnect()}catch(e){}try{r.u&&r.u.dispose&&r.u.dispose()}catch(e){}R.m.delete(id)}});");
patch('resetG-dispose',
  "G.clear();AN.clear();PN.clear();EQ.clear();SP.clear();BYP.clear();TR.clear()}",
  "TR.forEach(R=>R.m.forEach(r=>{try{r.u&&r.u.dispose&&r.u.dispose()}catch(e){}}));G.clear();AN.clear();PN.clear();EQ.clear();SP.clear();BYP.clear();TR.clear()}");

/* 3. VST状態(S.vst)は大きいので、履歴(Undo)と localStorage 自動保存から外す（.loom保存と専用ファイルには入る） */
patch('hist-skip-vst',
  "rep=(k,v)=>k=='buf'?(BUFS.includes(v)?BUFS.indexOf(v):BUFS.push(v)-1):v",
  "rep=(k,v)=>k=='vst'?undefined:k=='buf'?(BUFS.includes(v)?BUFS.indexOf(v):BUFS.push(v)-1):v");
patch('undo-keep-vst',
  "hx=i;S=JSON.parse(HS[i],rv);resetG();",
  "hx=i;{const vk=S.vst;S=JSON.parse(HS[i],rv);if(vk)S.vst=vk}resetG();");
patch('ls-skip-vst', "(k,v)=>k=='buf'?undefined:v", "(k,v)=>k=='buf'||k=='vst'?undefined:v", 2);

/* 4. ヘッダに VST ボタン */
patch('vst-button', '<button id="midi">MIDI</button>', '<button id="vstb" title="VST3プラグインのスキャン / 設定">VST</button><button id="midi">MIDI</button>');

/* 5. 外部フォントが読めなくてもフォールバックで動くのでそのまま。ブリッジを最後に読み込む */
patch('inject-scripts', '</script></body></html>', '</script>\n<script src="vst-core.js"></script>\n<script src="vst-bridge.js"></script>\n</body></html>');

fs.mkdirSync(path.join(root, 'app', 'www'), { recursive: true });
fs.writeFileSync(path.join(root, 'app', 'www', 'index.html'), h);
console.log('generated app/www/index.html from', srcFile, '(' + h.length + ' bytes)');
