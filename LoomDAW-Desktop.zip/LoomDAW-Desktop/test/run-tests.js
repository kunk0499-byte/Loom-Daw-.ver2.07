'use strict';
/* node test/run-tests.js — ホスト不要のJS側テスト（core / relay / WebSocket / モックホスト / スキャン） */
const assert = require('assert');
const path = require('path');
const C = require('../app/www/vst-core.js');
const { startRelay } = require('../app/relay');
const { scanAll } = require('../app/scan');
const H = C.H;
let passed = 0;
const ok = (n) => { passed++; console.log('  ok  ' + n); };

/* ── 1. core: フレーム符号化 ── */
{
  const evs = [[1234.5, 0x90, 60, 100, 0, 7], [99, 0, 0, 0, 1, 7]];
  const d = C.decodeEvents(C.encodeEvents(5, evs));
  assert.strictEqual(d.inst, 5); assert.deepStrictEqual(d.events, evs); ok('events encode/decode');
  const j = C.decodeJson(C.encodeJson(C.T.JSON_C, { id: 3, cmd: 'x', s: 'あ' })); assert.strictEqual(j.s, 'あ'); ok('json utf-8');
}

/* ── 2. core: リング drain → onAudioOut（ワークレット動作を模擬） ── */
{
  const CAP = 1024, B = 64, sab = C.makeSab(CAP), v = C.views(sab, CAP), h = v.h;
  C.resetRings(h, 128, B);
  Atomics.store(h, H.ACTIVE, 1);
  // ワークレットの初期化処理を再現
  Atomics.store(h, H.S0LO, 48000); Atomics.store(h, H.S0HI, 0); Atomics.store(h, H.OUT_W, 128); Atomics.store(h, H.STARTED, 1);
  const s = { v, inst: 9, B, s0: null, total: 0 };
  const sent = [];
  // 128フレーム分(2ブロック)入力
  let w = 0;
  for (let i = 0; i < 128; i++) { v.inR[((w + i) & v.mask) * 2] = i; v.inR[((w + i) & v.mask) * 2 + 1] = -i; }
  Atomics.store(h, H.IN_W, 128);
  assert.strictEqual(C.drain(s, b => sent.push(b)), 2);
  const dv0 = new DataView(sent[0]), dv1 = new DataView(sent[1]);
  assert.strictEqual(dv0.getFloat64(8, true), 48000); assert.strictEqual(dv1.getFloat64(8, true), 48064);
  assert.strictEqual(new Float32Array(sent[1], C.AUDIO_HDR, 128)[0], 64); ok('drain: frame positions + data');
  // 欠落(GAP)があるとフレーム位置が補正される
  Atomics.store(h, H.GAP, 10); w = 128;
  for (let i = 0; i < 64; i++) v.inR[((w + i) & v.mask) * 2] = 1;
  Atomics.store(h, H.IN_W, 192);
  C.drain(s, b => sent.push(b)); assert.strictEqual(new DataView(sent[2]).getFloat64(8, true), 48000 + 128 + 10); ok('drain: gap compensation');
  // 返ってきたブロックが OUT に入る
  assert.ok(C.onAudioOut(s, sent[1]));
  assert.strictEqual(Atomics.load(h, H.OUT_W), 128 + 64);
  assert.strictEqual(v.outR[(128 & v.mask) * 2], 64); ok('onAudioOut writes ring after DELAY');
  // オーバーフロー検出
  const big = C.encodeAudio(C.T.AUDIO_OUT, 9, 0, 1000); assert.strictEqual(C.onAudioOut(s, big.buf), false); assert.strictEqual(Atomics.load(h, H.OVER), 1); ok('onAudioOut overflow guard');
}

/* ── 3. relay + モックホスト + WebSocket(Node22標準クライアント) ── */
const mock = path.join(__dirname, 'mock-host.js');
(async () => {
  const relay = await startRelay({ hostCmd: process.execPath, hostArgs: [mock, '--serve'], onLog: () => {} });
  const bad = new WebSocket(`ws://127.0.0.1:${relay.port}/?t=wrong`);
  await new Promise(r => { bad.onerror = r; bad.onclose = r; }); ok('relay rejects wrong token');

  const ws = new WebSocket(`ws://127.0.0.1:${relay.port}/?t=${relay.token}`); ws.binaryType = 'arraybuffer';
  const inbox = [];
  ws.onmessage = e => inbox.push(e.data);
  await new Promise((r, j) => { ws.onopen = r; ws.onerror = () => j(new Error('ws error')); });
  const wait = async (pred, ms = 3000) => { const t0 = Date.now(); for (;;) { const i = inbox.findIndex(pred); if (i >= 0) return inbox.splice(i, 1)[0]; if (Date.now() - t0 > ms) throw new Error('timeout'); await new Promise(r => setTimeout(r, 5)); } };
  const isJson = id => b => new Uint8Array(b)[0] === C.T.JSON_H && C.decodeJson(b).id === id;

  ws.send(C.encodeJson(C.T.JSON_C, { id: 1, cmd: 'create', inst: 42, instrument: true }));
  const r1 = C.decodeJson(await wait(isJson(1))); assert.ok(r1.ok); ok('relay: create round-trip');

  // note on を frame=1000 に予約 → 1000以降のブロックで出力が 0.25 になる
  ws.send(C.encodeEvents(42, [[1000, 0x90, 60, 100, 0, 1]]));
  const input = C.encodeAudio(C.T.AUDIO_IN, 42, 960, 64); // 960..1023
  input.data.fill(0.5);
  ws.send(input.buf);
  const out = await wait(b => new Uint8Array(b)[0] === C.T.AUDIO_OUT);
  const d = new Float32Array(out, C.AUDIO_HDR, 128);
  assert.ok(Math.abs(d[0] - 0.25) < 1e-6, 'before note-on: input*0.5');          // frame 960
  assert.ok(Math.abs(d[(1000 - 960) * 2] - 0.5) < 1e-6, 'at note-on: 0.25+0.25'); // frame 1000
  assert.strictEqual(new DataView(out).getFloat64(8, true), 960); ok('relay: audio block + sample-accurate event timing');

  // 未発音イベントの取消(kind 1)
  ws.send(C.encodeEvents(42, [[5000, 0x90, 61, 100, 0, 2]])); ws.send(C.encodeEvents(42, [[0, 0, 0, 0, 1, 2]]));
  const i2 = C.encodeAudio(C.T.AUDIO_IN, 42, 5000, 64); i2.data.fill(0); ws.send(i2.buf);
  const o2 = await wait(b => new Uint8Array(b)[0] === C.T.AUDIO_OUT); assert.strictEqual(new Float32Array(o2, C.AUDIO_HDR, 2)[0], 0.25 /* note 60 は鳴りっぱなし */ ); ok('cancel pending by handle');
  ws.send(C.encodeEvents(42, [[0, 0, 0, 0, 2, 0]]));
  const i3 = C.encodeAudio(C.T.AUDIO_IN, 42, 6000, 64); i3.data.fill(0); ws.send(i3.buf);
  const o3 = await wait(b => new Uint8Array(b)[0] === C.T.AUDIO_OUT); assert.strictEqual(new Float32Array(o3, C.AUDIO_HDR, 2)[0], 0); ok('kind 2 clears all notes');

  // 大きなフレーム(>64KB, 拡張長さヘッダ)
  const bigIn = C.encodeAudio(C.T.AUDIO_IN, 42, 7000, 16384); bigIn.data.fill(0.1); ws.send(bigIn.buf);
  const bo = await wait(b => new Uint8Array(b)[0] === C.T.AUDIO_OUT); assert.strictEqual(new DataView(bo).getUint32(16, true), 16384); ok('large frame (64-bit length path)');
  ws.close();

  /* ── 4. スキャン(別プロセス) ── */
  const fs = require('fs'), os = require('os');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'loomvst-'));
  fs.mkdirSync(path.join(tmp, 'Vendor', 'Synth.vst3'), { recursive: true });
  fs.writeFileSync(path.join(tmp, 'Single.vst3'), 'x');
  // process.execPath をホストの代わりに使うため、薄いラッパを作る
  const wrap = path.join(tmp, process.platform === 'win32' ? 'wrap.cmd' : 'wrap.sh');
  fs.writeFileSync(wrap, process.platform === 'win32' ? `@"${process.execPath}" "${mock}" %*` : `#!/bin/sh\nexec "${process.execPath}" "${mock}" "$@"\n`, { mode: 0o755 });
  const cache = {};
  const res = await scanAll({ hostCmd: wrap, dirs: [tmp], cache, timeoutMs: 10000 });
  assert.strictEqual(res.total, 2); assert.strictEqual(res.plugins.length, 4); assert.strictEqual(res.failed.length, 0); ok('scan: finds .vst3 file+bundle, 2 plugins each, cached');
  const res2 = await scanAll({ hostCmd: '/nonexistent', dirs: [tmp], cache, timeoutMs: 1000 }); assert.strictEqual(res2.plugins.length, 4); ok('scan: cache reused (host not spawned)');

  relay.close();
  console.log(`\n${passed} checks passed`);
  process.exit(0);
})().catch(e => { console.error('FAILED:', e); process.exit(1); });
