'use strict';
/* mock-host.js — C++ホストと同じ stdio プロトコルを話すテスト用ホスト（VSTなしでJS側を検証する）
 * --scan-one <path> : ダミーのプラグイン一覧をJSONで出力
 * --serve           : create/destroy/editor/getState と AUDIO_IN→AUDIO_OUT, EVENTS を処理
 *   音声: 出力 = 入力×0.5 + (発音中なら 0.25 の定数) 。タイミング検証のため note-on フレームも記録する。 */
const C = require('../app/www/vst-core.js');
const args = process.argv.slice(2);

if (args[0] === '--scan-one') {
  process.stdout.write(JSON.stringify([
    { name: 'MockSynth', vendor: 'Loom', uid: '1001', isInstrument: true, numIn: 0, numOut: 2 },
    { name: 'MockFx', vendor: 'Loom', uid: '1002', isInstrument: false, numIn: 2, numOut: 2 }]));
  process.exit(0);
}

const insts = new Map();
const send = body => { const h = Buffer.alloc(4); h.writeUInt32LE(body.length, 0); process.stdout.write(Buffer.concat([h, Buffer.from(body)])); };
const sendJson = o => send(Buffer.from(C.encodeJson(C.T.JSON_H, o)));

function onFrame(b) {
  const ab = b.buffer.slice(b.byteOffset, b.byteOffset + b.length);
  const ty = b[0];
  if (ty === C.T.JSON_C) {
    const m = C.decodeJson(ab);
    if (m.cmd === 'create') { insts.set(m.inst, { notes: new Set(), pending: [], instrument: m.instrument }); sendJson({ id: m.id, ok: true, latency: 0, hasEditor: true }); }
    else if (m.cmd === 'destroy') { insts.delete(m.inst); sendJson({ id: m.id, ok: true }); }
    else if (m.cmd === 'editor') sendJson({ id: m.id, ok: true });
    else sendJson({ id: m.id, ok: false, error: 'unknown cmd' });
  } else if (ty === C.T.EVENTS) {
    const { inst, events } = C.decodeEvents(ab), s = insts.get(inst); if (!s) return;
    events.forEach(e => {
      if (e[4] === 0) s.pending.push(e);
      else if (e[4] === 1) s.pending = s.pending.filter(p => p[5] !== e[5]);
      else if (e[4] === 2) { s.pending = []; s.notes.clear(); }
    });
  } else if (ty === C.T.AUDIO_IN) {
    const dv = new DataView(ab), inst = dv.getUint32(4, true), start = dv.getFloat64(8, true), n = dv.getUint32(16, true);
    const s = insts.get(inst); if (!s) return;
    const x = new Float32Array(ab, C.AUDIO_HDR, n * 2), out = C.encodeAudio(C.T.AUDIO_OUT, inst, start, n);
    for (let i = 0; i < n; i++) {
      const f = start + i;
      s.pending = s.pending.filter(e => { if (e[0] <= f) { if (e[1] === 0x90) s.notes.add(e[2]); else s.notes.delete(e[2]); return false; } return true; });
      const g = s.notes.size ? 0.25 : 0;
      out.data[i * 2] = x[i * 2] * 0.5 + g; out.data[i * 2 + 1] = x[i * 2 + 1] * 0.5 + g;
    }
    send(Buffer.from(out.buf));
  }
}

let buf = Buffer.alloc(0);
process.stdin.on('data', d => {
  buf = Buffer.concat([buf, d]);
  for (;;) {
    if (buf.length < 4) return;
    const n = buf.readUInt32LE(0);
    if (buf.length < 4 + n) return;
    onFrame(Buffer.from(buf.subarray(4, 4 + n)));
    buf = buf.subarray(4 + n);
  }
});
process.stdin.on('end', () => process.exit(0));
