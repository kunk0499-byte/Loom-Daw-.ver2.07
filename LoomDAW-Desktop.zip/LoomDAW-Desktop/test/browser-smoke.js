'use strict';
/* node test/browser-smoke.js — 実ブラウザ(Chromium)で パッチ済みHTML + ブリッジ + relay + モックホスト を通しで検証。
 * Electron の代わりに node の http で app/www を COOP/COEP 付きで配信し、window.loomHost を偽装する。 */
const http = require('http'), fs = require('fs'), path = require('path');
const { startRelay } = require('../app/relay');
let pw; try { pw = require('playwright'); } catch (e) { pw = require(process.env.PW_PATH || '/home/claude/.npm-global/lib/node_modules/playwright'); }
const WWW = path.join(__dirname, '..', 'app', 'www');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript' };

(async () => {
  const relay = await startRelay({ hostCmd: process.execPath, hostArgs: [path.join(__dirname, 'mock-host.js'), '--serve'], onLog: () => {} });
  const srv = http.createServer((q, r) => {
    const f = path.join(WWW, q.url === '/' ? 'index.html' : q.url.split('?')[0]);
    if (!f.startsWith(WWW) || !fs.existsSync(f)) { r.writeHead(404); return r.end(); }
    r.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cross-Origin-Opener-Policy': 'same-origin', 'Cross-Origin-Embedder-Policy': 'credentialless' });
    fs.createReadStream(f).pipe(r);
  });
  await new Promise(r => srv.listen(0, '127.0.0.1', r));
  const url = 'http://127.0.0.1:' + srv.address().port + '/';

  const br = await pw.chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required', '--use-fake-ui-for-media-stream'] });
  const pg = await br.newPage();
  const errs = [];
  pg.on('pageerror', e => errs.push(String(e)));
  pg.on('console', m => { if (m.type() === 'error' && !/fonts\.googleapis|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); });
  await pg.addInitScript(({ port, token }) => {
    window.loomHost = {
      info: async () => ({ ok: true, port, token, dirs: [], plugins: { plugins: [
        { path: 'C:/x/Mock.vst3', name: 'MockSynth', vendor: 'Loom', uid: '1001', isInstrument: true },
        { path: 'C:/x/Mock.vst3', name: 'MockFx', vendor: 'Loom', uid: '1002', isInstrument: false }], failed: [] } }),
      scan: async () => ({ plugins: [], failed: [] }), pickFolder: async () => null, setDirs: async () => true,
      saveVstState: async () => true, loadVstState: async () => ({}), onScanProgress: () => {}
    };
  }, { port: relay.port, token: relay.token });
  await pg.goto(url);
  await pg.waitForFunction(() => typeof FXT !== 'undefined' && Object.keys(FXT).some(k => /^x:vst_/.test(k)), null, { timeout: 15000 });
  const iso = await pg.evaluate(() => crossOriginIsolated);
  if (!iso) throw new Error('not crossOriginIsolated');

  // 音源プラグインとして登録されているか
  const reg = await pg.evaluate(() => ({ ins: IL().filter(k => /vst_/.test(k)), fx: Object.keys(FXT).filter(k => /vst_/.test(k)) }));
  if (reg.ins.length !== 1 || reg.fx.length !== 1) throw new Error('registration: ' + JSON.stringify(reg));
  console.log('  ok  VST registered as instrument + effect:', JSON.stringify(reg));

  // VST音源トラックを作って発音 → マスターに音が出るか
  const peak = await pg.evaluate(async () => {
    initAudio();
    const idx = IL().findIndex(k => /vst_/.test(k));
    addTrack(7, idx, 0);
    const t = S.tracks[cur];
    await ac.resume();
    await new Promise(r => setTimeout(r, 1500));                       // ホスト接続・インスタンス作成待ち
    const R = IM.get(t) && [...IM.get(t).values()][0];
    if (!R || !R.u) throw new Error('instance missing');
    const st = R.u.status;
    const when = ac.currentTime + 0.4;
    play(7, t.pre, 60, when, 1.0, 0.8, tg(t), t);
    let pk = 0; const buf = new Float32Array(512);
    const t0 = performance.now();
    while (performance.now() - t0 < 2200) { MA.getFloatTimeDomainData(buf); for (const x of buf) pk = Math.max(pk, Math.abs(x)); await new Promise(r => setTimeout(r, 20)); }
    return { pk, st };
  });
  console.log('  info status:', peak.st, ' master peak:', peak.pk.toFixed(4));
  if (!(peak.pk > 0.01)) throw new Error('no audio came back through the VST bridge');
  console.log('  ok  VST instrument audio path (worklet → worker → relay → host → back)');

  // エフェクトノードを master に追加して通っても落ちない（passthrough→VST切替）
  const fxOk = await pg.evaluate(async () => {
    const key = Object.keys(FXT).find(k => /^x:vst_/.test(k));
    fxSc = 'm'; fgAdd(key, 400, 300); await new Promise(r => setTimeout(r, 1200));
    const id = FGD(S).n.find(n => n.ty === key).id;
    FGD(S).w.push(['t', id], [id, 'm']); fx();
    await new Promise(r => setTimeout(r, 800));
    return !!RTM.m.get(id) && !!RTM.m.get(id).u;
  });
  if (!fxOk) throw new Error('fx node not created');
  console.log('  ok  VST effect node created in master graph');

  // 削除でホスト側インスタンス解放(dispose)
  const left = await pg.evaluate(async () => { fgDel(FGD(S).n.find(n => /^x:vst_/.test(n.ty)).id); await new Promise(r => setTimeout(r, 300)); return window.__loomVst.insts.size; });
  console.log('  ok  node delete disposes instance; live instances now:', left);

  if (errs.length) throw new Error('page errors:\n' + errs.join('\n'));
  console.log('  ok  no page errors');
  await br.close(); relay.close(); srv.close();
  process.exit(0);
})().catch(e => { console.error('FAILED:', e.message || e); process.exit(1); });
