cmake_minimum_required(VERSION 3.22)
project(LoomVstHost VERSION 1.0.0 LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
# VC++ランタイムを静的リンク（インストーラ利用者にVC再頒布パッケージを要求しない）
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")

include(FetchContent)
FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git GIT_TAG 8.0.4 GIT_SHALLOW ON)
FetchContent_MakeAvailable(JUCE)

juce_add_gui_app(LoomVstHost PRODUCT_NAME "LoomVstHost" COMPANY_NAME "Loom")
target_sources(LoomVstHost PRIVATE Source/Main.cpp)
target_compile_definitions(LoomVstHost PRIVATE
    JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0
    JUCE_PLUGINHOST_VST3=1 JUCE_PLUGINHOST_VST=0 JUCE_PLUGINHOST_AU=0 JUCE_PLUGINHOST_LADSPA=0
    JUCE_MODAL_LOOPS_PERMITTED=0 JUCE_STRICT_REFCOUNTEDPOINTER=1
    JUCE_APPLICATION_NAME_STRING="LoomVstHost" JUCE_APPLICATION_VERSION_STRING="1.0.0")
target_link_libraries(LoomVstHost PRIVATE
    juce::juce_core juce::juce_events juce::juce_audio_basics juce::juce_audio_processors juce::juce_gui_basics
    juce::juce_recommended_config_flags)
