// LoomVstHost — Loom DAW 用 VST3 ホスト（サイドカー）
//   --scan-one <path.vst3> : プラグイン情報を JSON 配列で stdout に出して終了
//   --serve                : stdin/stdout の長さ前置フレームで音声・MIDI・制御をやり取り
// フレーム形式は app/www/vst-core.js の冒頭コメントと同一。
#include <juce_core/juce_core.h>
#include <juce_events/juce_events.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include <thread>
#include <map>
#include <mutex>
#include <atomic>
#include <memory>
#include <vector>
#include <cstring>
#include <algorithm>
#if JUCE_WINDOWS
 #include <windows.h>
#else
 #include <unistd.h>
#endif

using namespace juce;

// ───────────── バイナリ stdio ─────────────
static bool readExact (uint8* dst, size_t n)
{
    while (n > 0)
    {
#if JUCE_WINDOWS
        DWORD got = 0;
        if (! ReadFile (GetStdHandle (STD_INPUT_HANDLE), dst, (DWORD) n, &got, nullptr) || got == 0) return false;
#else
        auto got = ::read (0, dst, n); if (got <= 0) return false;
#endif
        dst += got; n -= (size_t) got;
    }
    return true;
}
static std::mutex outMutex;
static void writeAll (const uint8* p, size_t n)
{
    while (n > 0)
    {
#if JUCE_WINDOWS
        DWORD w = 0;
        if (! WriteFile (GetStdHandle (STD_OUTPUT_HANDLE), p, (DWORD) n, &w, nullptr) || w == 0) return;
#else
        auto w = ::write (1, p, n); if (w <= 0) return;
#endif
        p += w; n -= (size_t) w;
    }
}
static void sendFrame (const uint8* body, size_t n)
{
    std::lock_guard<std::mutex> l (outMutex);
    uint32 len = (uint32) n;                       // リトルエンディアン前提（x64 Windows）
    writeAll ((const uint8*) &len, 4);
    writeAll (body, n);
}
static void sendJson (const var& v)
{
    auto s = JSON::toString (v, true).toRawUTF8();
    std::vector<uint8> b; b.push_back (0x81); b.insert (b.end(), (const uint8*) s, (const uint8*) s + std::strlen (s));
    sendFrame (b.data(), b.size());
}

// ───────────── インスタンス ─────────────
struct Ev { double frame; uint8 st, d1, d2, kind; uint32 handle; };

struct Editor : public DocumentWindow
{
    std::function<void()> onClose;
    Editor (const String& name, AudioProcessorEditor* ed)
        : DocumentWindow (name, Colours::black, DocumentWindow::closeButton | DocumentWindow::minimiseButton)
    {
        setUsingNativeTitleBar (true);
        setContentOwned (ed, true);
        setResizable (ed->isResizable(), false);
        centreWithSize (getWidth(), getHeight());
    }
    void closeButtonPressed() override { setVisible (false); if (onClose) onClose(); }
};

struct Inst : public AudioProcessorListener
{
    uint32 id = 0;
    std::unique_ptr<AudioPluginInstance> p;
    std::unique_ptr<Editor> editor;
    CriticalSection lock;
    AudioBuffer<float> buf;
    int maxBlock = 512, inCh = 2, outCh = 2;
    bool instrument = false;
    std::vector<Ev> pending;          // 受信スレッド(=処理スレッド)専用なのでロック不要
    std::atomic<bool> dirty { false };
    String lastState;

    void audioProcessorParameterChanged (AudioProcessor*, int, float) override { dirty = true; }
    void audioProcessorChanged (AudioProcessor*, const ChangeDetails&) override { dirty = true; }
};

static std::mutex gMutex;
static std::map<uint32, std::shared_ptr<Inst>> gInsts;
static AudioPluginFormatManager gFm;

static std::shared_ptr<Inst> findInst (uint32 id)
{
    std::lock_guard<std::mutex> l (gMutex);
    auto it = gInsts.find (id);
    return it == gInsts.end() ? nullptr : it->second;
}

static String stateOf (Inst& i)
{
    MemoryBlock mb;
    { const ScopedLock sl (i.lock); i.p->getStateInformation (mb); }
    return mb.toBase64Encoding();
}

// 状態変化をまとめて通知（メッセージスレッドで1.5秒ごと）
struct StateTimer : public Timer
{
    void timerCallback() override
    {
        std::vector<std::shared_ptr<Inst>> v;
        { std::lock_guard<std::mutex> l (gMutex); for (auto& kv : gInsts) v.push_back (kv.second); }
        for (auto& i : v)
            if (i->dirty.exchange (false))
            {
                auto* o = new DynamicObject();
                o->setProperty ("evt", "state"); o->setProperty ("inst", (int) i->id); o->setProperty ("state", stateOf (*i));
                sendJson (var (o));
            }
    }
};

// ───────────── メッセージスレッドで実行して結果を待つ ─────────────
template <typename F>
static void onMessageThread (F&& f)
{
    if (MessageManager::getInstance()->isThisTheMessageThread()) { f(); return; }
    WaitableEvent ev;
    MessageManager::callAsync ([&] { f(); ev.signal(); });
    ev.wait();
}

static var jerr (int id, const String& msg)
{
    auto* o = new DynamicObject(); o->setProperty ("id", id); o->setProperty ("ok", false); o->setProperty ("error", msg); return var (o);
}

static std::unique_ptr<PluginDescription> pickDesc (const String& path, const String& uid, const String& name)
{
    VST3PluginFormat f;
    OwnedArray<PluginDescription> found;
    f.findAllTypesForFile (found, path);
    PluginDescription* best = nullptr;
    for (auto* d : found)
    {
        if (String (d->uniqueId) == uid || String (d->deprecatedUid) == uid) { best = d; break; }
        if (d->name == name && ! best) best = d;
    }
    if (! best && found.size() > 0) best = found[0];
    return best ? std::make_unique<PluginDescription> (*best) : nullptr;
}

static var doCreate (const var& m)
{
    const int rid = (int) m["id"];
    const uint32 inst = (uint32) (int64) m["inst"];
    const double sr = (double) m["sr"];
    const int block = jlimit (32, 2048, (int) m["block"]);
    const bool isInst = (bool) m["instrument"];
    var result;
    onMessageThread ([&]
    {
        auto d = pickDesc (m["path"].toString(), m["uid"].toString(), m["name"].toString());
        if (! d) { result = jerr (rid, "plugin not found"); return; }
        String err;
        auto p = gFm.createPluginInstance (*d, sr, block, err);
        if (! p) { result = jerr (rid, err.isEmpty() ? "create failed" : err); return; }

        // 入出力レイアウト: 音源=入力なし/ステレオ出力、エフェクト=ステレオ入出力
        AudioProcessor::BusesLayout lay;
        lay.inputBuses.add (isInst ? AudioChannelSet::disabled() : AudioChannelSet::stereo());
        lay.outputBuses.add (AudioChannelSet::stereo());
        if (p->getBusCount (true) == 0)  lay.inputBuses.clear();
        if (p->getBusCount (false) == 0) lay.outputBuses.clear();
        if (! p->setBusesLayout (lay)) { /* 既定レイアウトのまま使う */ }

        auto s = std::make_shared<Inst>();
        s->id = inst; s->instrument = isInst; s->maxBlock = block;
        s->p = std::move (p);
        auto st = m["state"].toString();
        if (st.isNotEmpty())
        {
            MemoryBlock mb;
            if (mb.fromBase64Encoding (st)) s->p->setStateInformation (mb.getData(), (int) mb.getSize());
        }
        s->p->setRateAndBufferSizeDetails (sr, block);
        s->p->prepareToPlay (sr, block);
        s->inCh = s->p->getTotalNumInputChannels(); s->outCh = s->p->getTotalNumOutputChannels();
        s->buf.setSize (jmax (2, jmax (s->inCh, s->outCh)), block);
        s->p->addListener (s.get());
        {
            std::lock_guard<std::mutex> l (gMutex);
            gInsts[inst] = s;                       // 同じIDの再作成(再接続)は置き換える
        }
        auto* o = new DynamicObject();
        o->setProperty ("id", rid); o->setProperty ("ok", true);
        o->setProperty ("latency", s->p->getLatencySamples()); o->setProperty ("hasEditor", s->p->hasEditor());
        result = var (o);
    });
    return result;
}

static void doDestroy (uint32 id)
{
    std::shared_ptr<Inst> s;
    { std::lock_guard<std::mutex> l (gMutex); auto it = gInsts.find (id); if (it != gInsts.end()) { s = it->second; gInsts.erase (it); } }
    if (! s) return;
    onMessageThread ([&]
    {
        s->p->removeListener (s.get());
        s->editor.reset();
        { const ScopedLock sl (s->lock); s->p->releaseResources(); }
        s->p.reset();
    });
}

static void doEditor (uint32 id, bool open)
{
    auto s = findInst (id); if (! s) return;
    MessageManager::callAsync ([s, open]
    {
        if (! open) { if (s->editor) s->editor->setVisible (false); return; }
        if (! s->editor)
        {
            auto* ed = s->p->createEditorIfNeeded();
            if (! ed) return;
            s->editor = std::make_unique<Editor> (s->p->getName(), ed);
            auto w = std::weak_ptr<Inst> (s);
            s->editor->onClose = [w] { if (auto q = w.lock()) q->dirty = true; };
        }
        s->editor->setVisible (true);
        s->editor->toFront (true);
    });
}

// ───────────── 音声ブロック処理 ─────────────
static void doAudio (const std::vector<uint8>& b)
{
    if (b.size() < 20) return;
    uint32 inst, n; double start;
    std::memcpy (&inst, &b[4], 4); std::memcpy (&start, &b[8], 8); std::memcpy (&n, &b[16], 4);
    auto s = findInst (inst);
    if (! s || b.size() < 20 + (size_t) n * 8) return;
    const int N = (int) n;
    const float* src = (const float*) &b[20];

    std::vector<uint8> out (20 + (size_t) N * 8, 0);
    out[0] = 0x82; std::memcpy (&out[4], &inst, 4); std::memcpy (&out[8], &start, 8); std::memcpy (&out[16], &n, 4);
    float* dst = (float*) &out[20];

    {
        const ScopedLock sl (s->lock);
        if (! s->p || N > s->buf.getNumSamples()) { sendFrame (out.data(), out.size()); return; }
        s->buf.clear();
        const int ch = s->buf.getNumChannels();
        if (! s->instrument)
            for (int i = 0; i < N; ++i)
            {
                s->buf.setSample (0, i, src[i * 2]);
                if (ch > 1) s->buf.setSample (1, i, src[i * 2 + 1]);
            }

        // 期限が来たMIDIをサンプル精度でバッファへ（遅れたものは先頭で発音）
        MidiBuffer midi;
        auto& pe = s->pending;
        for (size_t k = 0; k < pe.size();)
        {
            if (pe[k].frame < start + N)
            {
                int off = jlimit (0, N - 1, (int) (pe[k].frame - start));
                const uint8 data[3] = { pe[k].st, pe[k].d1, pe[k].d2 };
                midi.addEvent (data, (pe[k].st & 0xF0) == 0xC0 || (pe[k].st & 0xF0) == 0xD0 ? 2 : 3, off);
                pe.erase (pe.begin() + (long) k);
            }
            else ++k;
        }
        s->p->processBlock (s->buf, midi);

        const int oc = jmax (1, s->outCh);
        for (int i = 0; i < N; ++i)
        {
            float l = s->buf.getSample (0, i);
            float r = (oc > 1 && ch > 1) ? s->buf.getSample (1, i) : l;
            dst[i * 2] = l; dst[i * 2 + 1] = r;
        }
    }
    sendFrame (out.data(), out.size());
}

static void doEvents (const std::vector<uint8>& b)
{
    if (b.size() < 12) return;
    uint32 inst, cnt; std::memcpy (&inst, &b[4], 4); std::memcpy (&cnt, &b[8], 4);
    auto s = findInst (inst);
    if (! s || b.size() < 12 + (size_t) cnt * 16) return;
    for (uint32 i = 0; i < cnt; ++i)
    {
        const uint8* r = &b[12 + (size_t) i * 16];
        Ev e; std::memcpy (&e.frame, r, 8); e.st = r[8]; e.d1 = r[9]; e.d2 = r[10]; e.kind = r[11]; std::memcpy (&e.handle, r + 12, 4);
        if (e.kind == 0) s->pending.push_back (e);
        else if (e.kind == 1)
            s->pending.erase (std::remove_if (s->pending.begin(), s->pending.end(), [&] (const Ev& q) { return q.handle == e.handle; }), s->pending.end());
        else if (e.kind == 2)
        {
            s->pending.clear();
            // 全ノートオフ（次の音声ブロックの先頭で処理）
            for (int n = 0; n < 128; ++n) { Ev o { 0, 0x80, (uint8) n, 0, 0, 0 }; s->pending.push_back (o); }
        }
    }
}

static void handleJson (const std::vector<uint8>& b)
{
    var m = JSON::parse (String::fromUTF8 ((const char*) &b[1], (int) b.size() - 1));
    const String cmd = m["cmd"].toString();
    const int rid = (int) m["id"];
    if (cmd == "create") { sendJson (doCreate (m)); return; }
    if (cmd == "destroy") { doDestroy ((uint32) (int64) m["inst"]); auto* o = new DynamicObject(); o->setProperty ("id", rid); o->setProperty ("ok", true); sendJson (var (o)); return; }
    if (cmd == "editor")  { doEditor ((uint32) (int64) m["inst"], (bool) m["open"]); auto* o = new DynamicObject(); o->setProperty ("id", rid); o->setProperty ("ok", true); sendJson (var (o)); return; }
    if (cmd == "getState")
    {
        auto s = findInst ((uint32) (int64) m["inst"]);
        if (! s) { sendJson (jerr (rid, "no instance")); return; }
        auto* o = new DynamicObject(); o->setProperty ("id", rid); o->setProperty ("ok", true); o->setProperty ("state", stateOf (*s)); sendJson (var (o)); return;
    }
    sendJson (jerr (rid, "unknown cmd"));
}

// ───────────── アプリ ─────────────
class HostApp : public JUCEApplication
{
public:
    const String getApplicationName() override    { return "LoomVstHost"; }
    const String getApplicationVersion() override { return "1.0.0"; }
    bool moreThanOneInstanceAllowed() override    { return true; }

    void initialise (const String&) override
    {
        auto args = getCommandLineParameterArray();
        gFm.addFormat (new VST3PluginFormat());

        if (args.size() >= 2 && args[0] == "--scan-one")
        {
            VST3PluginFormat f;
            OwnedArray<PluginDescription> found;
            f.findAllTypesForFile (found, args[1]);
            Array<var> arr;
            for (auto* d : found)
            {
                auto* o = new DynamicObject();
                o->setProperty ("name", d->name);
                o->setProperty ("vendor", d->manufacturerName);
                o->setProperty ("uid", String (d->uniqueId));
                o->setProperty ("isInstrument", d->isInstrument);
                o->setProperty ("numIn", d->numInputChannels);
                o->setProperty ("numOut", d->numOutputChannels);
                arr.add (var (o));
            }
            auto s = JSON::toString (var (arr), true);
            writeAll ((const uint8*) s.toRawUTF8(), std::strlen (s.toRawUTF8()));
            setApplicationReturnValue (0);
            quit();
            return;
        }

        stateTimer = std::make_unique<StateTimer>();
        stateTimer->startTimer (1500);
        reader = std::thread ([this]
        {
            for (;;)
            {
                uint8 h[4];
                if (! readExact (h, 4)) break;
                uint32 n; std::memcpy (&n, h, 4);
                if (n == 0 || n > 64u * 1024u * 1024u) break;
                std::vector<uint8> b (n);
                if (! readExact (b.data(), n)) break;
                switch (b[0])
                {
                    case 0x01: handleJson (b); break;
                    case 0x02: doAudio (b);    break;
                    case 0x03: doEvents (b);   break;
                    default: break;
                }
            }
            MessageManager::callAsync ([] { JUCEApplication::getInstance()->systemRequestedQuit(); });   // 親(Electron)が終了したら自分も終了
        });
    }

    void shutdown() override
    {
        if (stateTimer) stateTimer->stopTimer();
        { std::lock_guard<std::mutex> l (gMutex); gInsts.clear(); }
        if (reader.joinable()) reader.detach();
    }
    void systemRequestedQuit() override { quit(); }

private:
    std::unique_ptr<StateTimer> stateTimer;
    std::thread reader;
};

START_JUCE_APPLICATION (HostApp)
